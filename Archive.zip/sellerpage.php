<?php
	session_start();
	//if (isset($_SESSION["userName"])&&!empty($_SESSION["userName"])){
	//	echo "<script type='text/javascript'>window.location.href = 'sellerpage.php';</script>";
	//}
?> 



<html>
	<head>
		<link type="text/css" rel="stylesheet" href="carstyles.css"/>
		<title>Sellers page</title>
	</head>
	<body>
		<div><a href="http://yahoo.com">fsdf</a></div>
		<div><a href="http://yahoo.com">fsdf</a></div>
		<div><a href="http://yahoo.com">fsdf</a></div>
	</body>
</html>


<!--<html>
	<head>
		
		<title>Sellers page</title>
	</head>

	<body>
		<a herf="http://yahoo.com" target="_blank">hihihi</a>
	<div style="height:10%;">
	<p> Welcome <?php //echo($_SESSION["userName"]); ?> </p>
	</div>

	<div style="height:20%;">
		<a herf="http://yahoo.com">hihihi</a>

		<a herf="http://yahoo.com"><img style="height:100%;" alt="Click to post" src="drawButton (1).png"/></a>
	</div>

	<div>
	Seller database should update this box with a list of cars the seller has posted
	also create a password verification for the log in page.
	</div>

	</body>

</html>

-->