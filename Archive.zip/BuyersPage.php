<DOCTYPE! html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link type="text/css" rel="stylesheet" href="carstyles.css"/>
<title>
Cars homepage</title>
</head>
<body>

<center>
<div class="container-fluid ">
<div class="jumbotron">
<h1>
Buyers Page
</h1>

</center>

</div>
<!--</div>-->

<!-- the btn-toolbar basically levels the buttons next to eachother -->
	<div style="height:auto; content:""; display:table" >
<!--buttonspacing makes a margin spacing so that buyer/leaser button isn't too close to seller button -->
<!--btn-primary2 makes the buttons shiny as does btn-seller -->
<a style="display:block; width:20%; float:left" href="createAd.php"><img style="max-width:20em; max-length:20em" src="RedHondaCivic.jpg"></a>

	<p style="float:center; color:Yellow; font-size:2em">
	&nbsp; &nbsp;Make:Honda<br>
	&nbsp; &nbsp;Model: Civic European Type R<br>
	&nbsp; &nbsp;Year:2011 probably<br>
	&nbsp; &nbsp;Milage:5000<br>
	&nbsp; &nbsp;Price:$5,000<br>
	&nbsp; &nbsp;Color:Red<br>
	</p>

	<a style="display:block; width:20%; float:left" href="createAd.php"><img style="max-width:20em; max-length:20em" src="RedHybrid.jpg"></a>

	<p style="float:center; color:Yellow; font-size:2em">
	&nbsp; &nbsp;Make:Toyota<br>
	&nbsp; &nbsp;Model:Some Prius Hybrid<br>
	&nbsp; &nbsp;Year:2015 probably<br>
	&nbsp; &nbsp;Milage:5000<br>
	&nbsp; &nbsp;Price:$5,000<br>
	&nbsp; &nbsp;Color:Orange<br>
	</p>


	<a style="display:block; width:20%; float:left" href="createAd.php"><img style="max-width:20em; max-length:20em" src="2015-Nissan-Leaf-C.jpg"></a>

	<p style="float:center; color:Yellow; font-size:2em">
	&nbsp; &nbsp;Make:Nissan<br>
	&nbsp; &nbsp;Model:Leaf-C<br>
	&nbsp; &nbsp;Year:2015<br>
	&nbsp; &nbsp;Milage:5000<br>
	&nbsp; &nbsp;Price:$5,000<br>
	&nbsp; &nbsp;Color:Blue<br>
	</p>



	</div>




</body>
