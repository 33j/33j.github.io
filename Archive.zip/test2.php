<?php

	unlink("images/0civic.jpg");


?>
